<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
    <title>English Lessons</title>
</head>

<body>

    <div class="container">

        <div class="navigation-bar">
            <nav>
                <ul>
                    <a href="engDash.html"><img class="exit-icon" src="images/open-door.png" alt="black-user-icon"></a>
                </ul>
            </nav>
        </div>

        <table class="table-kids">
            <tr>
                <th>Topic</th>
                <th>Description</th>
                <th>Files</th>
            </tr>

            <tr>
                <td>Alphabet Worksheets Resources</td>
                <td>Learn the Alphabet Worksheets Resources</td>
                <td><a href="https://agendaweb.org/grammar/alphabet-worksheets-resources.html"
                        target="_blank">Alphabets</a></td>
            </tr>

            <tr>
                <td>Alphabet & Vowels Exercises</td>
                <td>Learn the Basic Vowels of the Alphabets</td>
                <td><a href="https://agendaweb.org/grammar/alphabet-exercises.html" target="_blank">Vowels</a></td>
            </tr>

            <tr>
                <td>Spelling Exercises</td>
                <td>Learn Spelling of Alphabets of Objects</td>
                <td><a href="https://agendaweb.org/grammar/alphabet-spelling" target="_blank">Spelling</a></td>
            </tr>

            <tr>
                <td>Alphabet Worksheets</td>
                <td>Learn the Order of the Alphabets</td>
                <td><a href="https://agendaweb.org/grammar/alphabet-order-exercises.html" target="_blank">Alphabet
                        Orders</a>
                </td>
            </tr>
    </div>
    </table>

    <div>
        <img class="img-children-playing"
            src="https://t3.ftcdn.net/jpg/03/07/79/36/360_F_307793604_YXSFaT5g1YyPVwCjTxo2KsYUHp5tdvw2.jpg">

    </div>

</body>

</html>