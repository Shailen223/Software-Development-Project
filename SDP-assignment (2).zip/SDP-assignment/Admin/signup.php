<?php
include 'db_connection.php';

if (isset($_POST['create-user'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];
  $username = $_POST['username'];
  $mobile = $_POST['mobile'];
  $key = 'TTW';

  $sql = "SELECT * FROM user WHERE email = '$email' OR password = '$password' OR username = '$username' OR mobile = '$mobile'";
  $result = mysqli_query($connection, $sql);


  if (mysqli_num_rows($result) > 0) {
    $err = "This email is created before!";
    $_SESSION['msg'] = $err;
    header('location:signup.php');
  } elseif (strpos($password, $key)) {
    $insert2 = "INSERT INTO admin (email, username, password, mobile) VALUES ('$email', '$password', '$username', '$mobile') ";
    mysqli_query($connection, $insert2);
    echo '<script>alert("Successfully created a new account! Now Login!"); 
              window.location.href = "login.php";
          </script>';
  } else {
    $sqlReg = "INSERT INTO user (email, username, password, mobile) VALUES ('$email', '$password', '$username', '$mobile')";
    mysqli_query($connection, $sqlReg);
    echo '<script>alert("Successfully created a new account! Now Login!"); 
              window.location.href = "login.php";
          </script>';
  }
}
?>



<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="asset/css/bootstrap.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="fontawesome/css/all.min.css" rel="stylesheet" type="text/css">
  <title>Sign Up</title>
  <style type="text/css">
    .bg-hero {
      background-color: #bfd0f1;
    }

    .info-text {
      font-size: 14px;
      font-weight: 700;
      margin-bottom: 0px;
      text-align: left;
    }

    .info-text1 {
      color: #383636;
      font-size: 14px;
      margin-bottom: 0px;
      text-align: left;
    }

    .icon-size {
      font-size: 3rem;
    }

    .ps-1-5 {
      padding-left: 0.3rem !important;
    }
  </style>

</head>

<body>

  <?php include 'components/navbar.php'; ?>

  <section class="py-5 text-center  bg-hero">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <h1 class="fw-light">SIGN UP</h1>
        <p class="lead text-muted fs-6">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don’t simply skip over it entirely.</p>
      </div>
    </div>
  </section>

  <div class="container-fluid px-4 py-5 d-flex justify-content-center">
    <div class="row flex-lg-row-reverse g-5 py-5 col-10 align-items-center">

      <div class="col-md-10 mx-auto col-lg-7">
        <form class="p-4 p-md-5 border rounded-3 bg-light" action="#" method="POST">
          <h4>REGISTER NEW ACCOUNT</h4>
          <?php if (!empty($_SESSION['msg'])) { ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong>Alert: </strong> <?php echo $_SESSION['msg']; ?>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
          <?php $_SESSION['msg'] = '';
          } ?>
          <div class="form-floating mb-3 mt-3">
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter Your Email" autocomplete="off">
            <label for="email">Enter Your Email</label>
          </div>
          <div class="form-floating mb-3">
            <input type="password" class="form-control" id="password" name="password" placeholder="Enter Passsword">
            <label for="password">Enter Password</label>
          </div>
          <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control" id="name" name="username" placeholder="Enter Your Name">
            <label for="name">Enter Your Name</label>
          </div>
          <div class="form-floating mb-3 mt-3">
            <input type="number" class="form-control" id="mobile" name="mobile" placeholder="Enter Your Mobile">
            <label for="mobile">Enter Your Mobile</label>
          </div>
          <div class="mt-4">
            <p>Already Have Account? <a href="login.php">Login Now</a></p>
          </div>
          <input class="btn btn-primary btn-sm px-4 py-2" type="submit" name="create-user" value="Register" />
          <a class="btn btn-secondary btn-sm px-4 py-2" href="login.php">Login Now</a>
        </form>
      </div>

      <div class="col-lg-5 text-center text-lg-start">
        <div class="col-lg-12 fs-4 d-flex align-items-center">


          <img src="asset/img/img2.png" class="w-100">


        </div>

      </div>

    </div>
  </div>


  <script src="asset/js/bootstrap.bundle.min.js"></script>
  <script src="asset/js/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {

    });
  </script>
</body>

</html>