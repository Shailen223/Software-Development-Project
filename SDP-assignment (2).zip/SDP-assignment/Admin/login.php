<?php
include 'db_connection.php';
// If admin has the correct id behind their username
// They will be logged in under admin 
// else they will be logged in under students / users
// if the password and username matches they will be logged in
// else they cannot log in
// User Login
if (isset($_POST['login'])) {
  $email = $_POST['email'];
  $pass = $_POST['password'];
  $sql = "SELECT * FROM user WHERE email = '$email' AND password = '$pass'";
  $result = mysqli_query($connection, $sql);


  if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);

    // check password
    if ($row['email'] == $email && $row['password'] == $pass) {
      $_SESSION['email'] = $row['email'];
      $_SESSION['password'] = $row['password'];
      echo '<script>alert("Successfully Login to Account."); 
      			</script>';
      header('location: dashboard.php');
    } else {

      $err = "Invalid Credential.";
      $_SESSION['msg'] = $err;
      header('location:login.php');
    }
  }
}

// Admin Login 
if (isset($_POST['login'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];
  $select2 = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";
  $result2 = mysqli_query($connection, $select2);
  $key = 'TTW';

  if (mysqli_num_rows($result2) == 1) {
    $row = mysqli_fetch_assoc($result2);
    if ($row['email'] == $email && $row['password'] == $password) {
      // Check if password contains key ID
      if (strpos($password, $key))
        $_SESSION['email'] = $row['email'];
      $_SESSION['password'] = $row['password'];
      echo '<script>alert("Successfully Login to Account."); 
      window.location.href = "admin.php";
  </script>';
    }
  } else {
    $invalid = 1;
  }
}
?>

<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="asset/css/bootstrap.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="fontawesome/css/all.min.css" rel="stylesheet" type="text/css">
  <title>Login</title>
  <style type="text/css">
    .bg-hero {
      background-color: #bfd0f1;
    }

    .info-text {
      font-size: 14px;
      font-weight: 700;
      margin-bottom: 0px;
      text-align: left;
    }

    .info-text1 {
      color: #383636;
      font-size: 14px;
      margin-bottom: 0px;
      text-align: left;
    }

    .icon-size {
      font-size: 3rem;
    }

    .ps-1-5 {
      padding-left: 0.3rem !important;
    }
  </style>

</head>

<body>

  <?php include 'components/navbar.php'; ?>
  <section class="py-5 text-center  bg-hero">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <h1 class="fw-light">SIGN IN</h1>
        <p class="lead text-muted fs-6">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don’t simply skip over it entirely.</p>
      </div>
    </div>
  </section>

  <div class="container-fluid px-4 py-5 d-flex justify-content-center">
    <div class="row flex-lg-row-reverse g-5 py-5 col-10 align-items-center">

      <div class="col-md-10 mx-auto col-lg-7">
        <form class="p-4 p-md-5 border rounded-3 bg-light" action="#" method="POST">
          <h4>SIGN IN</h4>
          <?php if (!empty($_SESSION['msg'])) { ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong>Alert: </strong> <?php echo $_SESSION['msg']; ?>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
          <?php $_SESSION['msg'] = '';
          } ?>
          <div class="form-floating mb-3 mt-3">
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter Your Email">
            <label for="email">Enter Your Email</label>
          </div>
          <div class="form-floating mb-3">
            <input type="password" class="form-control" id="password" name="password" placeholder="Enter Passsword">
            <label for="password">Enter Password</label>
          </div>
          <div class="mt-4">
            <p>Dont Have An Account? <a href="signup.php">Register Now</a></p>
          </div>
          <input class="btn btn-primary btn-sm px-4 py-2" type="submit" value="Login" name="login" />
          <a class="btn btn-secondary btn-sm px-4 py-2" href="signup.php">Register</a>
        </form>
      </div>

      <div class="col-lg-5 text-center text-lg-start">
        <div class="col-lg-12 fs-4 d-flex align-items-center">


          <img src="asset/img/img1.jpeg" class="w-100">


        </div>

      </div>

    </div>
  </div>


  <script src="asset/js/bootstrap.bundle.min.js"></script>
  <script src="asset/js/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {

    });
  </script>
</body>

</html>