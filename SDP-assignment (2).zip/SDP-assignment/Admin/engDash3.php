<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
    <title>StoryBooks</title>
</head>

<body>
    <div class="container">
        <div class="navigation-bar">
            <nav>
                <ul>
                    <a href="engDash.html"><img class="exit-icon" src="images/open-door.png" alt="black-user-icon"></a>
                </ul>
            </nav>
        </div>

        <div class="story-title">
            <h2>StoryBooks</h2>
        </div>

        <div class="flex">
            <div class="box-1">
                <div><img class="story-thumbnails" src="https://illustoon.com/photo/8331.png" alt="">
                    <div class="story-caption">
                        <div class="box=1-2">
                            <div><a href="slides1.html"><button class="read-btn-btn">Read Now</button></a></div>
                            <h1>The Little Gingerbread Man</h1>
                            <p>- by Carol Moore -</p>
                            <p>A surprising new version of the classic Gingerbread Man fairy tale.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="box-2">
                <div><img class="story-thumbnails" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTB7VSUsrZzQv0CoE2OHzYVzYVcvyKobmbZ4w&usqp=CAU">
                    <div class="story-caption1">
                        <div class="box-1-2">
                            <div><a href="slides2.html"><button class="read-btn-btn">Read Now</button></a></div>
                            <h1>Pirate's Treasure</h1>
                            <p>- by Carol Moore - Illustrated by Aura Moser - </p>
                            <p>A pirate in Jimmmy's dream tells him where to find buried treasure.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="box-3">
                <div><img class="story-thumbnails" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqpidpcMwP23M4jjV2F7tsMJEYTsdNeUXgSA&usqp=CAU" alt="">
                    <div class="story-caption2">
                        <div class="box-1-2-2">
                            <div><a href="slides3.html"><button class="read-btn-btn">Read Now</button></a></div>
                            <h1>Wolstencroft The Bear</h1>
                            <p>- by Karen Lewis - Illustrated by Michael S. Weber.e -</p>
                            <p>Not long ago and not far away there was a beautiful, big teddy bear who sat on a
                                shelf in a drug store waiting for someone to buy him and give him a home.
                                <br> His name was Wolstencroft. And he was no ordinary bear.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="box-4-1">
                <div>
                    <span>#1</span>
                </div>
                <div>
                    <span>#2</span>
                </div>
                <div>
                    <span>#3</span>
                </div>
            </div>
        </div>

    </div>
</body>

</html>