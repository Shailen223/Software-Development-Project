<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="asset/css/bootstrap.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

  <link href="fontawesome/css/all.min.css" rel="stylesheet" type="text/css">
  <title>ContactUs</title>
  <style type="text/css">
    .bg-hero {
      background-color: #bfd0f1;
    }

    .info-text {
      font-size: 14px;
      font-weight: 700;
      margin-bottom: 0px;
      text-align: left;
    }

    .info-text1 {
      color: #383636;
      font-size: 14px;
      margin-bottom: 0px;
      text-align: left;
    }

    .icon-size {
      font-size: 3rem;
    }

    .ps-1-5 {
      padding-left: 0.3rem !important;
    }
  </style>

</head>

<body>

  <?php include 'components/navbar.php'; ?>

  <section class="py-5 text-center  bg-hero">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <h1 class="fw-light">Contact Us</h1>
        <p class="lead text-muted fs-6">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don’t simply skip over it entirely.</p>
      </div>
    </div>
  </section>

  <div class="container-fluid px-4 py-5 d-flex justify-content-center">
    <div class="row flex-lg-row-reverse g-5 py-5 col-10">

      <div class="col-lg-4 text-center text-lg-start">
        <div class="col-lg-10 fs-4 d-flex align-items-center">

          <p class="mb-0"><i class="fas fa-home icon-size"></i></p>
          <div class="d-grid ms-3">

            <p class="info-text">Retail Store</p>
            <p class="info-text1">48, Jalan Hijau, Tamen Kuching, 57000, Bukit Jalil Kuala Lumpur</p>

          </div>

        </div>
        <div class="col-lg-10 fs-4 d-flex align-items-center mt-4">

          <p class="mb-0 ps-1-5"><i class="fas fa-phone-square-alt icon-size"></i></p>
          <div class="d-grid ms-3">

            <p class="info-text">+012-6565435</p>
            <p class="info-text1">Mon to Sun 9am to 10pm</p>

          </div>

        </div>
        <div class="col-lg-10 fs-4 d-flex align-items-center mt-4">

          <p class="mb-0"><i class="fas fa-envelope icon-size"></i></p>
          <div class="d-grid ms-3">

            <p class="info-text">anyaforger@gmail.com</p>
            <p class="info-text1">Send us your query anytime!</p>

          </div>

        </div>
      </div>
      <div class="col-md-10 mx-auto col-lg-8">
        <form class="p-4 p-md-5 border rounded-3 bg-light" action="function.php" method="POST">
          <h4>Get In Touch</h4>
          <div class="mb-3 mt-3">
            <label for="message" class="form-label">Messages</label>
            <textarea class="form-control" id="message" rows="5" name="message"></textarea>
          </div>
          <div class="row">
            <div class="col">
              <div class="form-floating mb-3">
                <input type="text" class="form-control" id="name" placeholder="Enter Your Name" name="name">
                <label for="name">Enter Your Name</label>
              </div>
            </div>
            <div class="col">
              <div class="form-floating mb-3">
                <input type="email" class="form-control" id="email" placeholder="Enter Your Email" name="email">
                <label for="email">Enter Your Email</label>
              </div>
            </div>
          </div>
          <div class="form-floating mb-3">
            <input type="text" class="form-control" id="subject" placeholder="Enter Subject" name="subject">
            <label for="subject">Enter Subject</label>
          </div>
          <input class="btn btn-primary btn-sm rounded-pill px-4 py-2" type="submit" value="Send Message" name="sendMsg" />

        </form>
      </div>
    </div>
  </div>


  <script src="asset/js/bootstrap.bundle.min.js"></script>
  <script src="asset/js/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#navbars .nav-item .nav-link[href="contact.php"]').addClass('active');
    });
  </script>
</body>

</html>