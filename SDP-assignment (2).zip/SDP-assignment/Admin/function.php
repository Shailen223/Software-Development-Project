<!-- Contat Us Sending A Message -->
<?php

include 'dbcon.php';
session_start();

if (isset($_POST['sendMsg'])) {


	$email = $_POST['email'];
	$name = $_POST['name'];
	$subject = $_POST['subject'];
	$message = $_POST['message'];



	$sqlReg = "INSERT INTO comment (message, name, email, subject) VALUES ('$message', '$name', '$email', '$subject')";

	if (mysqli_query($conn, $sqlReg)) {

		echo '<script>alert("Successfully send message!"); 
						  window.location.href = "contact.php";
					</script>';
	} else {
		echo '<script>alert("Failed to send message!"); 
						  window.location.href = "contact.php";
					</script>';
	}
}


?>