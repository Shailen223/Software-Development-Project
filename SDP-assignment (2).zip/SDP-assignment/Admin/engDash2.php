<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/main.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
    <title>English Lessons</title>
</head>

<body>

    <div class="container">

        <div class="navigation-bar">
            <nav>
                <ul>
                    <a href="engDash.html"><img class="exit-icon" src="images/open-door.png" alt="black-user-icon"></a>
                </ul>
            </nav>
        </div>

        <table class="table-kids">
            <tr>
                <th>Topic</th>
                <th>Description</th>
                <th>Files</th>
            </tr>

            <?php
            include 'db_connection.php';
            $query = 'SELECT * FROM english_books';
            $result = mysqli_query($connection, $query);
            $files = scandir('uploads');
            ?>


            <?php while ($row = mysqli_fetch_assoc($result)) {
                $id = $row['ID'] ?>
                <tr>
                    <td> <?php echo $row['topic']; ?></td>
                    <td> <?php echo $row['content']; ?></td>
                    <td> <?php

                            for ($a  = 5; count($files) > $a; $a++) {

                            ?>
                            <a href="uploads/<?php echo $files[$a] ?>"><?php echo $row['files']; ?></a>
                        <?php
                            }
                        ?>
                    </td>
                </tr>
            <?php } ?>
    </div>
    </table>

    <div>
        <img class="img-children-playing" src="https://t3.ftcdn.net/jpg/03/07/79/36/360_F_307793604_YXSFaT5g1YyPVwCjTxo2KsYUHp5tdvw2.jpg">

    </div>

</body>

</html>