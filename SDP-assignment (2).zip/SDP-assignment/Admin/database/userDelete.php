<?php
include 'db_connection.php';

$id = $_GET['id'];

$query = "DELETE FROM user WHERE ID = $id";
if (mysqli_query($connection, $query)) {
    header('location: user.php');
} else {
    echo mysqli_error($connection);
}
