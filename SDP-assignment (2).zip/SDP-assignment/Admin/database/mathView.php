<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/main.css?v=<?php echo time(); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
    <title>View Files</title>
</head>

<body>
    <div class="container">
        <div class="navigation-bar">
            <nav>
                <ul>
                    <li><img src="../images/usericon2.png" alt="black-user-icon"></li>
                </ul>
            </nav>
        </div>


        <div class="sidebar">
            <ul>
                <li><a href="mathView.php">View Lesson</a></li>
                <li><a href="mathAdd.php">Add Lesson</a></li>
                <li><a href="#">View Exercises</a></li>
                <li><a href="admin.php">Back</a></li>
            </ul>
        </div>

        <table border="2" cellspacing="2" cellpadding="4" width="75%">
            <tr>
                <th>ID</th>
                <th>Topic</th>
                <th>Description</th>
                <th>Files</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>

            <?php
            include 'db_connection.php';
            $query = 'SELECT * FROM math_books';
            $result = mysqli_query($connection, $query);
            $files = scandir('../uploadsMath');

            ?>

            <?php while ($row = mysqli_fetch_assoc($result)) {
                $id = $row['ID'] ?>
                <tr>
                    <td> <?php echo $row['ID']; ?> </td>
                    <td> <?php echo $row['topic']; ?></td>
                    <td> <?php echo $row['content']; ?></td>
                    <td> <?php

                            for ($a  = 5; count($files) > $a; $a++) {

                            ?>
                            <a href="../uploadsMath/<?php echo $files[$a] ?>"><?php echo $row['files']; ?></a>
                        <?php
                            }
                        ?>
                    </td>
                    <td> <a class="links" href="mathUpdate.php?id=<?php echo $id; ?>">Edit</a></td>
                    <td> <a class="links" href='mathDel.php?id=<?php echo $id; ?>' onclick="return confirm('Are you sure?')">Delete</a></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>

</html>