<!-- User Account Table View -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Database</title>
    <link rel="stylesheet" href="../css/user.css" ?v=<?php echo time(); ?>>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
</head>

<body>
    <h1>User Database</h1>
    <h2>User Information</h2>
    <div class="buttons">
        <button class="link"><a href="userAdd.php">Add user to database</a></button>
        <button class="link2"><a href=" admin.php">Back to home</a></button>
    </div>


    <?php
    include 'db_connection.php';
    ?>

    <table border="1" cellspacing="2" cellpadding="4" width="100%">
        <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Username</th>
            <th>Password</th>
            <th>Mobile</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <!-- View data table -->
        <?php
        $query = 'SELECT * FROM user';
        $result = mysqli_query($connection, $query);
        ?>

        <?php while ($row = mysqli_fetch_assoc($result)) {
            $id = $row['ID'] ?>
            <tr>
                <td><?php echo $row['ID']; ?> </td>
                <td> <?php echo $row['email']; ?></td>
                <td> <?php echo $row['username']; ?></td>
                <td> <?php echo $row['password']; ?></td>
                <td> <?php echo $row['mobile']; ?></td>
                <td><a href="userEdit.php?id=<?php echo $id; ?>">Edit</a></td>
                <td><a href='userDelete.php?id=<?php echo $id; ?>' onclick="return confirm('Are you sure?')">Delete</a></td>
            </tr>
        <?php } ?>
    </table>

</body>

</html>