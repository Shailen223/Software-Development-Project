<?php
include 'db_connection.php';
if (isset($_POST['submit'])) {
    $topic = $_POST['topic'];
    $content = $_POST['content'];
    $file = $_FILES['file']['name'];
    $file2 = $_FILES['file'];               // Upload to server


    $insert = "INSERT INTO `math_books` (topic, content, files) 
            VALUES('$topic','$content','$file')";
    $result = mysqli_query($connection, $insert);
    if ($result) {
        move_uploaded_file($file2['tmp_name'], '../uploadsMath/' . $file2['name']);
        header("Location: mathView.php");
    } else {
        die(mysqli_error($connection));
    }
}
