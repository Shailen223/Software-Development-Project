<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/user.css?v=<?php echo time(); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
    <title>Add New User</title>
</head>

<body>
    <div class="container">
        <form action="#" method="POST">
            <div class="title1">
                <h1>User Account Form</h1>
            </div>
            <div class="user">
                <h2>Add User Information</h2>
                <p class="email">Email</p>
                <input class="info" name="email" type="email" required>
                <p>Username</p>
                <input class="info" name="name" type="text" required>
                <p>Password</p>
                <input class="info" name="password" type="password" required>
                <p>Number</p>
                <input class="info" name="number" type="mobile-number" required>
            </div>

            <div class="submit-btns">
                <input class="save-button" type="submit" name="submit" value="Save">
                <a href="user.php" target="_self" class="cancel-button">Cancel</a>
            </div>
        </form>

        <!-- Php Form -->

        <?php
        include 'db_connection.php';
        if (isset($_POST['submit'])) {
            $email = $_POST['email'];
            $name = $_POST['name'];
            $password = $_POST['password'];
            $mobile = $_POST['number'];

            $insert = "INSERT INTO `user` (email, username, password, mobile) 
            VALUES('$email','$name','$password', '$mobile')";
            $result = mysqli_query($connection, $insert);
            if ($result) {
                echo 'Data inserted successfully!';
            } else {
                die(mysqli_error($connection));
            }
        }

        ?>
    </div>

</body>

</html>