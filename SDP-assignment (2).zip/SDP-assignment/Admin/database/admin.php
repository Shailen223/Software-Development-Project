<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css?v=<?php echo time(); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
    <title>Admin</title>
</head>

<body>
    <div class="container">
        <div class="navigation-bar">
            <nav>
                <ul>
                    <a href="../logout.php" onclick="return confirm('Logout?')"><img class="exit-icon" src="../images/open-door.png" alt="black-user-icon"></a>
                </ul>
            </nav>
        </div>

        <div class="title">
            <h2>Admin Page</h2>
        </div>

        <div class="flex-box">
            <div class="">
                <a href="engView.php">
                    <img class="img-1" src="https://learnenglishkids.britishcouncil.org/sites/kids/files/styles/max_650x650/public/image/worksheets-acrostic-poems_1.png?itok=UGyPVkI7" alt="Picture of an english icon">
                </a>
                <p>English</p>

            </div>

            <div class="">
                <a href="mathView.php">
                    <img class="img-2" src="../images/math-blackboard.jpg" alt="Picture of a math icon">
                </a>
                <p>Mathematics</p>
            </div>

            <div class="">
                <a href="user.php">
                    <img class="img-3" src="../images/user-icon.jpg" alt="Picture of a user icon">
                </a>
                <p>Users</p>

            </div>

        </div>

    </div>

</body>

</html>