<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/main.css?v=<?php echo time(); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ibarra+Real+Nova&family=Poppins&family=Roboto&display=swap" rel="stylesheet">
    <title>View Files</title>
</head>

<body>
    <div class="container">
        <div class="navigation-bar">
            <nav>
                <ul>
                    <li><img src="images/usericon2.png" alt="black-user-icon"></li>
                </ul>
            </nav>
        </div>


        <table border="2" class="table" id="table">
            <tr>
                <th>Topic</th>
                <th>Description</th>
                <th>Files</th>
                <th>Action</th>
            </tr>

        </table>

        <div class="sidebar">
            <ul>
                <li><a href="engView.php">View Lesson</a></li>
                <li><a href="engAdd.php">Add Lesson</a></li>
                <li><a href="engUpdate.php">Update Lesson</a></li>
                <li><a href="engDel.php">Delete Lesson</a></li>
                <li><a href="admin.php">Back</a></li>
            </ul>
        </div>
    </div>


</body>

<?php
include 'db_connection.php';

$id = $_GET['id'];

$query = "DELETE FROM english_books WHERE ID = $id";
if (mysqli_query($connection, $query)) {
    header('location: engView.php');
} else {
    echo mysqli_error($connection);
}
?>

</html>