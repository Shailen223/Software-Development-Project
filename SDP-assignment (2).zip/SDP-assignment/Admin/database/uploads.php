<?php
include 'db_connection.php';
if (isset($_POST['submit'])) {
    $topic = $_POST['topic'];
    $content = $_POST['content'];
    $file = $_FILES['file']['name'];        // Save to database
    $file2 = $_FILES['file'];               // Upload to server


    $insert = "INSERT INTO `english_books` (topic, content, files) 
        VALUES('$topic','$content','$file')";
    $result = mysqli_query($connection, $insert);
    if ($result) {
        move_uploaded_file($file2['tmp_name'], '../uploads/' . $file2['name']);
        header("Location: engView.php");
    } else {
        die(mysqli_error($connection));
    }
}
