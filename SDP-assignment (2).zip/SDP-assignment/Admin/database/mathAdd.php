<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/main.css?v=<?php echo time(); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
    <title>Math Database</title>
</head>

<body>

    <div class="container">
        <div class="navigation-bar">
            <nav>
                <ul>
                    <li><img src="images/usericon2.png" alt="black-user-icon"></li>
                </ul>
            </nav>
        </div>
        <!-- Data and form submission -->

        <form action="uploadsMath.php" method="POST" enctype="multipart/form-data">
            <div class="content">
                <p class="title">Add Math Lesson</p>
                <button type="submit" class="submit-btn" name="submit">Submit</button>
                <p>Topic</p>
                <div>
                    <input class="topic" type="text" name="topic" id="topic" placeholder="Lesson name" required>
                </div>
                <p>Content</p>
                <div>
                    <input class="content-placeholder" type="text" name="content" id="content" placeholder="Brief description" required>
                </div>
                <p>File (PDF, Word File, Excel)</p>
                <div>
                    <input class="choose-file-btn" name="file" name="choose-file" type="file">
                </div>
            </div>

        </form>


        <div class="sidebar">
            <ul>
                <li><a href="mathView.php">View Lesson</a></li>
                <li><a href="mathAdd.php">Add Lesson</a></li>
                <li><a href="#">View Exercises</a></li>
                <li><a href="admin.php">Back</a></li>
            </ul>
        </div>
    </div>



</body>



</html>