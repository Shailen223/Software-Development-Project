<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/main.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../css/math.css?v=<?php echo time(); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
    <title>View Files</title>
</head>

<body>
    <div class="container">
        <div class="navigation-bar">
            <nav>
                <ul>
                    <li><img src="images/usericon2.png" alt="black-user-icon"></li>
                </ul>
            </nav>
        </div>


        <div class="content-box">
            <h1 class="topic">Topic </h1>
            <h1 class="sub-topics"> <a href="#">- Addition</a> <br> <a href="#">- Subtraction</a> <br> <a href="#">- Multiplication</a> <br> <a href="#">- Division</a>
                <!-- <a href="#">- Timetable</a> -->
            </h1>
            <div class="img">
                <img class="img-brain" src="images/mathbrain.jpg" alt="brain-thicking-picture">

            </div>

        </div>



        <!-- <div class="sidebar">
            <ul>
                <li><a href="mathView.php">View Lesson</a></li>
                <li><a href="mathAdd.php">Add Lesson</a></li>
                <li><a href="#">Update Lesson</a></li>
                <li><a href="#">Delete Lesson</a></li>
                <li><a href="admin.php">Back</a></li>
            </ul>
        </div> -->
    </div>

</body>
<?php
include 'db_connection.php';

$id = $_GET['id'];

$query = "DELETE FROM math_books WHERE ID = $id";
if (mysqli_query($connection, $query)) {
    header('location: mathView.php');
} else {
    echo mysqli_error($connection);
}
?>

</html>