<?php
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'rstw_db';
$connection = mysqli_connect($hostname, $username, $password, $database);

if ($connection === false) {
    die('Connection error' . mysqli_connect_error());
} else {
    // echo 'connection established';
}
