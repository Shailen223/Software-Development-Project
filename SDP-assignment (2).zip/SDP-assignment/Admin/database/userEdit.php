<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/user.css?v=<?php echo time(); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
    <title>Edit and Update Users</title>
</head>

<?php
include 'db_connection.php';
$id = $_GET['id'];
$sql3 = "SELECT * FROM `user` WHERE id=$id";
$result3 = mysqli_query($connection, $sql3);
$row = mysqli_fetch_assoc($result3);
$email2 = $row['email'];
$username2 = $row['username'];
$password2 = $row['password'];
$mobile2 = $row['mobile'];
?>

<?php
include 'db_connection.php';
if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $mobile = $_POST['mobile'];

    $insert = "UPDATE `user` SET id=$id, email='$email', username='$username', password='$password', mobile='$mobile' WHERE id=$id";
    $result = mysqli_query($connection, $insert);
    if ($result) {
        header('location: user.php');
    } else {
        die(mysqli_error($connection));
    }
}
?>

<body>
    <div class="container">
        <form action="#" method="POST">
            <div class="title1">
                <h1>User Account Form</h1>
            </div>
            <div class="user">
                <h2>Update User Information</h2>
                <p>Email</p>
                <input class="info" name="email" type="email" value=<?php echo $email2; ?> required>
                <p>Username</p>
                <input class="info" name="username" type="text" value=<?php echo $username2; ?> required>
                <p>Password</p>
                <input class="info" name="password" type="text" value=<?php echo $password2; ?> required>
                <p>Mobile</p>
                <input class="info" name="mobile" type="text" value=<?php echo $mobile2; ?> required>
            </div>
    </div>

    <div class="submit-btns">
        <input class="save-button" type="submit" name="submit" value="Save">
        <a href="user.php" target="_self" class="cancel2-button">Cancel</a>
    </div>


</body>

</html>