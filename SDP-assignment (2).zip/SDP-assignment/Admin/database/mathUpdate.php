<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/user.css?v=<?php echo time(); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
    <title>Edit and Update Lessons </title>
</head>

<?php
include 'db_connection.php';
$id = $_GET['id'];
$sql3 = "SELECT * FROM `math_books` WHERE id=$id";
$result3 = mysqli_query($connection, $sql3);
$row = mysqli_fetch_assoc($result3);
$email2 = $row['topic'];
$username2 = $row['content'];
$password2 = $row['files'];
?>

<?php
include 'db_connection.php';
if (isset($_POST['submit'])) {
    $email = $_POST['topic'];
    $username = $_POST['content'];
    $password = $_FILES['file']['name'];
    $fileTemp = $_FILES['file']['nameTemp'];
    $file_folder = 'upload_Folder/' . $file;

    $insert = "UPDATE `math_books` SET id=$id, topic='$email', content='$username', files='$password' WHERE id=$id";
    $result = mysqli_query($connection, $insert);
    if ($result) {
        move_uploaded_file($fileTemp, $file_folder);
        header('location: mathView.php');
    } else {
        die(mysqli_error($connection));
    }
}
?>

<body>
    <div class="container">
        <form action="#" method="POST" enctype="multipart/form-data">
            <div class="title1">
                <h1>Math Lesson Form</h1>
            </div>
            <div class="user">
                <h2>Update Math Lesson</h2>
                <p>Topic</p>
                <input class="info" name="topic" type="text" value=<?php echo $email2; ?> required>
                <p>Content</p>
                <input class="info" name="content" type="text" value=<?php echo $username2; ?> required>
                <p>Files</p>
                <input class="info-file" name="file" type="file" value=<?php echo $password2; ?> required>
            </div>
    </div>

    <div class="submit-btns">
        <input class="save-button" type="submit" name="submit" value="Save" onclick="return confirm('Confirm Update?')">
        <a href="mathView.php" target="_self" class="cancel2-button">Cancel</a>
    </div>


</body>

</html>