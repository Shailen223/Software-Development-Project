<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="asset/css/bootstrap.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

  <title>Home Page</title>
  <style type="text/css">
    .bg-hero {
      background-color: #bfd0f1;
    }
  </style>

</head>

<body>

  <?php include 'components/navbar.php'; ?>

  <div class="container-fluid px-4 py-5 bg-hero d-flex justify-content-center">
    <div class="row flex-lg-row-reverse align-items-center g-5 py-5 col-10">
      <div class="col-10 col-sm-8 col-lg-6">
        <img src="images/elearning.png" class="d-block mx-lg-auto img-fluid" width="700" height="600" loading="lazy">
      </div>
      <div class="col-lg-6">
        <h1 class="display-5 fw-bold lh-1 mb-3">DIGITAL LEARNING, <br> Simplified</h1>
        <p class="lead">Power School is doing everything we can to make it easy for districts to get up and running with distance learning</p>
        <div class="d-grid gap-2 d-md-flex justify-content-md-start">
          <a href="login.php"><button type="button" class="btn btn-primary px-4 me-md-2 rounded-pill">LOGIN</button></a>
        </div>
      </div>
    </div>
  </div>


  <script src="asset/js/bootstrap.bundle.min.js"></script>
  <script src="asset/js/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#navbars .nav-item .nav-link[href="index.php"]').addClass('active');
    });
  </script>
</body>

</html>