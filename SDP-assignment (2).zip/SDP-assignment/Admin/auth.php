<?php


if (isset($_POST['login'])) {

	$email = $_POST['email'];
	$pass = $_POST['password'];

	$sql = "SELECT * FROM user WHERE email = '$email' AND password = '$pass'";
	$result = mysqli_query($conn, $sql);


	if (mysqli_num_rows($result) == 1) {
		$row = mysqli_fetch_assoc($result);

		// check password
		if ($row['email'] == $email && $row['password'] == $pass) {
			// $_SESSION['uid'] = $row['id'];
			$_SESSION['email'] = $row['email'];
			$_SESSION['password'] = $row['password'];
			echo '<script>alert("Successfully Login to Account."); 
							  window.location.href = "admin/dashboard.php";
						</script>';
		} else {

			$err = "Invalid Credential.";
			$_SESSION['msg'] = $err;
			header('location:login.php');
		}
	}
}



if (isset($_POST['create-user'])) {


	$email = $_POST['email'];
	$name = $_POST['name'];
	$mobile = $_POST['mobile'];
	$password = $_POST['password'];


	$sql = "SELECT * FROM user where email = '$email'";
	$result = mysqli_query($conn, $sql);


	if (mysqli_num_rows($result) > 0) {

		$err = "This email is created before!";
		$_SESSION['msg'] = $err;
		header('location:signup.php');
	} else {

		$sqlReg = "INSERT INTO user (email, password, name, mobile) VALUES ('$email', '$password', '$name', '$mobile')";

		if (mysqli_query($conn, $sqlReg)) {

			echo '<script>alert("Successfully create new account!"); 
							  window.location.href = "signup.php";
						</script>';
		} else {
			$err = "Error: Failed to create account!";
			$_SESSION['msg'] = $err;
			header('location:signup.php');
		}
	}
}
