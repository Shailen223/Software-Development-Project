<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="asset/css/bootstrap.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


  <title>About Us</title>
  <style type="text/css">
    .bg-hero {
      background-color: #bfd0f1;
    }
  </style>

</head>

<body>

  <?php include 'components/navbar.php'; ?>

  <div class="container-fluid px-4 py-5 bg-hero d-flex justify-content-center">
    <div class="row flex-lg-row-reverse align-items-center g-5 py-5 col-10">

      <div class="col-lg-7">
        <h1 class="display-5 fw-bold lh-1 mb-3">About Us</h1>
        <p class="lead">The "RSTW Project" is a project that wishes to connect students and children
          from the rural areas of Malaysia to the basics ot knowledge and primary educatiom
          It is an e-learning platform, or a tree online learning platform where students can
          access various basic core study materials and worksheet materials such as languages
          and mathematics tor practices.</p>
      </div>
      <div class="col-10 col-sm-8 col-lg-5">
        <img src="images/elearning2.jpeg" class="d-block mx-lg-auto img-fluid" width="700" height="600" loading="lazy">
      </div>

    </div>
  </div>


  <script src="asset/js/bootstrap.bundle.min.js"></script>
  <script src="asset/js/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#navbars .nav-item .nav-link[href="aboutus.php"]').addClass('active');
    });
  </script>
</body>

</html>