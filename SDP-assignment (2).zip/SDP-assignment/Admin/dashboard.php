<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container">
        <div class="navigation-bar">
            <nav>
                <ul>
                    <!-- Logout / Exit -->
                    <a href="logout.php" onclick="return confirm('Do you wish to logout?')"><img class="exit-icon" src="images/open-door.png" alt="black-user-icon"></a>

                </ul>
            </nav>
        </div>
        <div class="title">
            <h2>Choose Your Subject</h2>
        </div>

        <div class="flex-box">
            <div class="">
                <a href="engDash.html">
                    <img class="img-1" src="images/book.png" alt="Picture of an english book">
                </a>
                <p>English</p>
            </div>

            <div class="">
                <a href="mathDash.html">
                    <img class="img-2" src="images/math-time.jpg" alt="Picture of a math logo">
                </a>
                <p>Math</p>
            </div>

        </div>

    </div>

</body>

</html>