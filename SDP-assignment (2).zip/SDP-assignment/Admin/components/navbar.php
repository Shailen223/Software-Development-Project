<?php

session_start();


?>

<nav class="navbar navbar-expand-md navbar-light header-color hpadding">
  <div class="container">
    <a class="navbar-brand" href="#">RSTW</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbars" aria-controls="navbars" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbars">
      <ul class="navbar-nav me-auto ms-auto mb-2 mb-md-0">
        <li class="nav-item px-3">
          <a class="nav-link" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" aria-current="page" href="aboutus.php">About Us</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" aria-current="page" href="guide.php">Guide</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" aria-current="page" href="contact.php">Contact Us</a>
        </li>
      </ul>
      <div>
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <?php if (empty($_SESSION["uid"])) { ?>
              <a class="nav-link btn btn-sm btn-primary text-white rounded-pill px-4 fs-8 fw-bold" aria-current="page" href="login.php">LOGIN</a>
            <?php } else { ?>
              <a class="nav-link btn btn-sm btn-danger text-white rounded-pill px-4 fs-8 fw-bold" aria-current="page" href="logout.php">LOGOUT</a>
            <?php } ?>
          </li>
        </ul>
      </div>
    </div>
  </div>
</nav>